import { useLocation, Link } from "react-router-dom";
import { useEffect } from "react";
import { motion } from "framer-motion";
import { Home, ArrowLeft } from "lucide-react";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname,
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-luxury-black relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-luxury-accent/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-luxury-glow/5 rounded-full blur-3xl animate-pulse" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-center relative z-10 px-8"
      >
        <motion.h1
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2, duration: 0.6 }}
          className="text-8xl md:text-9xl font-bold mb-6 bg-gradient-to-r from-luxury-white to-luxury-accent bg-clip-text text-transparent"
        >
          404
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
          className="text-2xl md:text-3xl text-luxury-white/80 mb-4"
        >
          Page Not Found
        </motion.p>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.6 }}
          className="text-lg text-luxury-white/60 mb-12 max-w-md mx-auto"
        >
          The page you're looking for doesn't exist or has been moved.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.6 }}
          className="flex flex-col sm:flex-row gap-4 justify-center items-center"
        >
          <Link
            to="/"
            className="group relative px-8 py-4 bg-luxury-accent text-luxury-black font-semibold rounded-lg overflow-hidden magnetic glow-hover transition-all duration-300 hover:scale-105 flex items-center gap-2"
          >
            <Home className="w-5 h-5" />
            <span className="relative z-10">Return Home</span>
            <div className="absolute inset-0 bg-luxury-glow opacity-0 group-hover:opacity-20 transition-opacity duration-300" />
          </Link>

          <button
            onClick={() => window.history.back()}
            className="group relative px-8 py-4 bg-transparent border border-luxury-accent/50 text-luxury-white font-semibold rounded-lg magnetic hover:border-luxury-accent transition-all duration-300 hover:scale-105 flex items-center gap-2"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="relative z-10">Go Back</span>
          </button>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default NotFound;
