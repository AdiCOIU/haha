import React from "react";
import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import ITVideoBackground from "../components/ITVideoBackground";
import Navigation from "../components/Navigation";

const Portfolio: React.FC = () => {
  return (
    <div className="relative min-h-screen">
      <ITVideoBackground />
      <Navigation />
      
      <div className="relative z-10 min-h-screen flex items-center justify-center px-8 pt-20">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center max-w-4xl mx-auto"
        >
          <h1 className="text-5xl md:text-7xl font-bold mb-8 bg-gradient-to-r from-luxury-white to-luxury-accent bg-clip-text text-transparent">
            Portfolio
          </h1>
          
          <div className="w-16 h-px bg-luxury-accent mx-auto mb-8" />
          
          <p className="text-xl text-luxury-white/70 mb-12 leading-relaxed">
            This page is coming soon. Continue building your portfolio by asking for more content.
          </p>
          
          <Link
            to="/"
            className="group inline-flex items-center gap-2 px-8 py-4 bg-luxury-accent text-luxury-black font-semibold rounded-lg hover:scale-105 transition-all duration-300"
          >
            <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform duration-300" />
            Back to Home
          </Link>
        </motion.div>
      </div>
    </div>
  );
};

export default Portfolio;
