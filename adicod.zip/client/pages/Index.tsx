import React, { useEffect, useRef, useState } from "react";
import { motion, useAnimation, useInView, useScroll, useTransform } from "framer-motion";
import { ArrowDown, Github, Linkedin, Mail, ExternalLink, Download, ChevronUp, Code, Palette, Zap, Globe } from "lucide-react";
import GeometricBackground from "../components/GeometricBackground";
import GeometricHero from "../components/GeometricHero";
import Navigation from "../components/Navigation";
import AuthPanel from "../components/AuthPanel";
import TestimonialsCarousel from "../components/TestimonialsCarousel";
import { useParallax } from "../hooks/useParallax";

const FloatingElement: React.FC<{ delay?: number; children: React.ReactNode }> = ({ delay = 0, children }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.8, ease: "easeOut" }}
      className="animate-float"
    >
      {children}
    </motion.div>
  );
};

const AnimatedText: React.FC<{ text: string; delay?: number; className?: string }> = ({ 
  text, 
  delay = 0, 
  className = "" 
}) => {
  const words = text.split(" ");
  
  return (
    <div className={className}>
      {words.map((word, i) => (
        <motion.span
          key={i}
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{
            delay: delay + (i * 0.1),
            duration: 0.6,
            ease: "easeOut",
          }}
          className="inline-block mr-2"
        >
          {word}
        </motion.span>
      ))}
    </div>
  );
};

const HeroSection: React.FC = () => {
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 500], [0, -100]);
  const opacity = useTransform(scrollY, [0, 300], [1, 0]);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden noise pt-20">
      {/* Ambient Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-luxury-accent/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-luxury-glow/5 rounded-full blur-3xl animate-pulse" />
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-radial from-luxury-accent/5 to-transparent rounded-full blur-2xl" />
      </div>

      {/* Floating Geometric Shapes */}
      <div className="absolute inset-0 pointer-events-none">
        <FloatingElement delay={1}>
          <div className="absolute top-20 left-20 w-4 h-4 bg-luxury-accent/30 rotate-45 animate-glow" />
        </FloatingElement>
        <FloatingElement delay={1.5}>
          <div className="absolute top-40 right-32 w-6 h-6 border border-luxury-accent/50 rotate-12" />
        </FloatingElement>
        <FloatingElement delay={2}>
          <div className="absolute bottom-40 left-1/3 w-8 h-8 bg-gradient-to-br from-luxury-accent/20 to-luxury-glow/20 rounded-full" />
        </FloatingElement>
      </div>

      <motion.div 
        style={{ y, opacity }}
        className="relative z-10 text-center px-8 max-w-6xl mx-auto"
      >
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 1 }}
          className="mb-8"
        >
          <div className="w-20 h-px bg-gradient-to-r from-transparent via-luxury-accent to-transparent mx-auto mb-8" />
        </motion.div>

        <AnimatedText
          text="I design and build premium digital experiences"
          delay={0.8}
          className="text-4xl md:text-7xl font-bold leading-tight mb-6 bg-gradient-to-r from-luxury-white via-luxury-white to-luxury-accent bg-clip-text text-transparent"
        />

        <AnimatedText
          text="— elegant, fast, and precise."
          delay={1.8}
          className="text-xl md:text-3xl font-light text-luxury-white/80 mb-12"
        />

        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 2.5, duration: 0.8 }}
          className="text-lg md:text-xl text-luxury-white/60 max-w-2xl mx-auto mb-16 leading-relaxed"
        >
          Frontend developer and designer crafting exceptional web experiences 
          with modern technologies and attention to detail.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 3, duration: 0.8 }}
          className="flex flex-col sm:flex-row gap-6 justify-center items-center"
        >
          <button className="group relative px-8 py-4 bg-luxury-accent text-luxury-black font-semibold rounded-lg overflow-hidden magnetic glow-hover transition-all duration-300 hover:scale-105">
            <span className="relative z-10">View My Work</span>
            <div className="absolute inset-0 bg-luxury-glow opacity-0 group-hover:opacity-20 transition-opacity duration-300" />
          </button>
          
          <button className="group relative px-8 py-4 bg-transparent border border-luxury-accent/50 text-luxury-white font-semibold rounded-lg magnetic hover:border-luxury-accent transition-all duration-300 hover:scale-105">
            <span className="relative z-10 flex items-center gap-2">
              Get In Touch
              <ExternalLink className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-300" />
            </span>
          </button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 4, duration: 1 }}
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
        >
          <div className="flex flex-col items-center text-luxury-white/50">
            <span className="text-sm font-mono mb-2">Scroll Down</span>
            <ArrowDown className="w-5 h-5 animate-bounce" />
          </div>
        </motion.div>
      </motion.div>
    </section>
  );
};

const AboutSection: React.FC = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.3 });
  const controls = useAnimation();

  useEffect(() => {
    if (isInView) {
      controls.start("visible");
    }
  }, [isInView, controls]);

  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: "easeOut",
      },
    },
  };

  const skills = [
    "React & Next.js",
    "TypeScript",
    "Three.js",
    "GSAP & Framer Motion",
    "TailwindCSS",
    "Node.js",
    "GraphQL",
    "WebGL"
  ];

  return (
    <section ref={ref} className="relative py-32 px-8">
      <div className="max-w-7xl mx-auto">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={controls}
          className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center"
        >
          <motion.div variants={itemVariants}>
            <div className="relative">
              <h2 className="text-5xl md:text-6xl font-bold mb-8 bg-gradient-to-r from-luxury-white to-luxury-accent bg-clip-text text-transparent">
                About Me
              </h2>
              <div className="w-16 h-px bg-luxury-accent mb-8" />
              
              <div className="space-y-6 text-luxury-white/80 text-lg leading-relaxed">
                <p>
                  I'm a passionate frontend developer with 5+ years of experience creating 
                  digital experiences that blend aesthetics with functionality. My work 
                  focuses on crafting interfaces that are not just visually stunning, 
                  but also performant and accessible.
                </p>
                <p>
                  Specializing in modern web technologies, I bring ideas to life through 
                  clean code, innovative animations, and user-centered design. Every project 
                  is an opportunity to push boundaries and create something exceptional.
                </p>
              </div>

              <motion.button
                variants={itemVariants}
                className="group mt-8 flex items-center gap-2 text-luxury-accent hover:text-luxury-glow transition-colors duration-300"
              >
                <Download className="w-5 h-5" />
                <span className="font-semibold">Download Resume</span>
                <div className="w-0 group-hover:w-full h-px bg-luxury-accent transition-all duration-300" />
              </motion.button>
            </div>
          </motion.div>

          <motion.div variants={itemVariants} className="relative">
            <div className="glass rounded-2xl p-8 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-luxury-accent/5 to-luxury-glow/5" />
              
              <h3 className="text-2xl font-bold text-luxury-white mb-6">Skills & Technologies</h3>
              
              <div className="grid grid-cols-2 gap-4">
                {skills.map((skill, index) => (
                  <motion.div
                    key={skill}
                    initial={{ opacity: 0, x: -20 }}
                    animate={isInView ? { opacity: 1, x: 0 } : {}}
                    transition={{ delay: 0.5 + index * 0.1, duration: 0.6 }}
                    className="group relative bg-luxury-gray-800/50 rounded-lg p-4 border border-luxury-gray-700 hover:border-luxury-accent/50 transition-all duration-300 cursor-pointer"
                  >
                    <span className="text-luxury-white font-medium">{skill}</span>
                    <div className="absolute inset-0 bg-luxury-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-lg" />
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

const ProjectCard: React.FC<{
  title: string;
  description: string;
  image: string;
  technologies: string[];
  link?: string;
  delay?: number;
}> = ({ title, description, technologies, delay = 0 }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay, duration: 0.8, ease: "easeOut" }}
      className="group relative glass rounded-2xl overflow-hidden cursor-pointer magnetic"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative h-64 bg-gradient-to-br from-luxury-gray-800 to-luxury-gray-900 overflow-hidden">
        <motion.div
          animate={{ scale: isHovered ? 1.1 : 1 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="absolute inset-0 bg-gradient-to-br from-luxury-accent/20 to-luxury-glow/20"
        />
        <div className="absolute inset-0 flex items-center justify-center">
          <motion.div
            animate={{ opacity: isHovered ? 1 : 0.7 }}
            className="text-6xl font-bold text-luxury-white/20"
          >
            {title.slice(0, 2)}
          </motion.div>
        </div>
      </div>

      <div className="p-6">
        <h3 className="text-2xl font-bold text-luxury-white mb-3">{title}</h3>
        <p className="text-luxury-white/70 mb-4 leading-relaxed">{description}</p>
        
        <div className="flex flex-wrap gap-2 mb-4">
          {technologies.map((tech) => (
            <span
              key={tech}
              className="px-3 py-1 bg-luxury-gray-800 text-luxury-accent text-sm rounded-full border border-luxury-gray-700"
            >
              {tech}
            </span>
          ))}
        </div>

        <div className="flex items-center gap-4">
          <button className="flex items-center gap-2 text-luxury-accent hover:text-luxury-glow transition-colors duration-300">
            <ExternalLink className="w-4 h-4" />
            <span className="font-semibold">View Project</span>
          </button>
          <button className="flex items-center gap-2 text-luxury-white/60 hover:text-luxury-white transition-colors duration-300">
            <Github className="w-4 h-4" />
            <span>Code</span>
          </button>
        </div>
      </div>

      <motion.div
        animate={{ opacity: isHovered ? 1 : 0 }}
        className="absolute inset-0 bg-gradient-to-t from-luxury-accent/10 to-transparent pointer-events-none"
      />
    </motion.div>
  );
};

const ServicesSection: React.FC = () => {
  const services = [
    {
      icon: Code,
      title: "Frontend Development",
      description: "Building responsive, performant web applications with modern frameworks and best practices.",
      technologies: ["React", "Next.js", "TypeScript", "TailwindCSS"]
    },
    {
      icon: Palette,
      title: "UI/UX Design",
      description: "Creating intuitive and visually stunning interfaces that prioritize user experience.",
      technologies: ["Figma", "Adobe Suite", "Prototyping", "Design Systems"]
    },
    {
      icon: Zap,
      title: "Performance Optimization",
      description: "Ensuring your applications are lightning-fast with advanced optimization techniques.",
      technologies: ["Web Vitals", "Bundle Analysis", "CDN", "Caching"]
    },
    {
      icon: Globe,
      title: "Full-Stack Solutions",
      description: "End-to-end development from concept to deployment with scalable architecture.",
      technologies: ["Node.js", "GraphQL", "PostgreSQL", "AWS"]
    }
  ];

  return (
    <section className="relative py-32 px-8 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-luxury-black via-luxury-gray-900/50 to-luxury-black" />

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-luxury-white to-luxury-accent bg-clip-text text-transparent">
            Services
          </h2>
          <div className="w-16 h-px bg-luxury-accent mx-auto mb-8" />
          <p className="text-xl text-luxury-white/70 max-w-2xl mx-auto">
            Comprehensive solutions to bring your digital vision to life.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2, duration: 0.8 }}
                className="group relative glass rounded-2xl p-8 hover:border-luxury-accent/50 transition-all duration-500"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-luxury-accent/5 to-luxury-glow/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-2xl" />

                <div className="relative z-10">
                  <motion.div
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    className="w-16 h-16 bg-luxury-accent/20 rounded-lg flex items-center justify-center mb-6"
                  >
                    <Icon className="w-8 h-8 text-luxury-accent" />
                  </motion.div>

                  <h3 className="text-2xl font-bold text-luxury-white mb-4">{service.title}</h3>
                  <p className="text-luxury-white/70 mb-6 leading-relaxed">{service.description}</p>

                  <div className="flex flex-wrap gap-2">
                    {service.technologies.map((tech) => (
                      <span
                        key={tech}
                        className="px-3 py-1 bg-luxury-gray-800/50 text-luxury-accent text-sm rounded-full border border-luxury-gray-700 group-hover:border-luxury-accent/50 transition-colors duration-300"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

const PortfolioSection: React.FC = () => {
  const projects = [
    {
      title: "E-Commerce Platform",
      description: "A modern e-commerce platform with advanced filtering, real-time inventory, and seamless checkout experience.",
      image: "/placeholder.svg",
      technologies: ["React", "Next.js", "Stripe", "PostgreSQL"],
    },
    {
      title: "Creative Agency Website",
      description: "Award-winning creative agency website featuring immersive animations and interactive portfolio showcase.",
      image: "/placeholder.svg",
      technologies: ["Three.js", "GSAP", "React", "Sanity"],
    },
    {
      title: "SaaS Dashboard",
      description: "Comprehensive analytics dashboard with real-time data visualization and advanced reporting features.",
      image: "/placeholder.svg",
      technologies: ["React", "D3.js", "Node.js", "MongoDB"],
    },
  ];

  return (
    <section className="relative py-32 px-8">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-luxury-white to-luxury-accent bg-clip-text text-transparent">
            Featured Work
          </h2>
          <div className="w-16 h-px bg-luxury-accent mx-auto mb-8" />
          <p className="text-xl text-luxury-white/70 max-w-2xl mx-auto">
            A selection of projects that showcase my skills in creating 
            exceptional digital experiences.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <ProjectCard
              key={project.title}
              {...project}
              delay={index * 0.2}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

const ContactSection: React.FC = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log("Form submitted:", formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <section className="relative py-32 px-8">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-luxury-white to-luxury-accent bg-clip-text text-transparent">
            Let's Build Something Exceptional
          </h2>
          <div className="w-16 h-px bg-luxury-accent mx-auto mb-8" />
          <p className="text-xl text-luxury-white/70">
            Ready to bring your vision to life? Let's discuss your next project.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3, duration: 0.8 }}
          className="glass rounded-2xl p-8 relative overflow-hidden"
        >
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="relative">
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full bg-luxury-gray-800/50 border border-luxury-gray-700 rounded-lg px-4 py-3 text-luxury-white placeholder-luxury-white/50 focus:border-luxury-accent focus:outline-none transition-colors duration-300 peer"
                  placeholder=" "
                />
                <label className="absolute left-4 top-3 text-luxury-white/50 transition-all duration-300 peer-focus:-translate-y-6 peer-focus:text-luxury-accent peer-focus:text-sm peer-[:not(:placeholder-shown)]:-translate-y-6 peer-[:not(:placeholder-shown)]:text-luxury-accent peer-[:not(:placeholder-shown)]:text-sm">
                  Your Name
                </label>
              </div>

              <div className="relative">
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full bg-luxury-gray-800/50 border border-luxury-gray-700 rounded-lg px-4 py-3 text-luxury-white placeholder-luxury-white/50 focus:border-luxury-accent focus:outline-none transition-colors duration-300 peer"
                  placeholder=" "
                />
                <label className="absolute left-4 top-3 text-luxury-white/50 transition-all duration-300 peer-focus:-translate-y-6 peer-focus:text-luxury-accent peer-focus:text-sm peer-[:not(:placeholder-shown)]:-translate-y-6 peer-[:not(:placeholder-shown)]:text-luxury-accent peer-[:not(:placeholder-shown)]:text-sm">
                  Email Address
                </label>
              </div>
            </div>

            <div className="relative">
              <textarea
                name="message"
                value={formData.message}
                onChange={handleChange}
                required
                rows={6}
                className="w-full bg-luxury-gray-800/50 border border-luxury-gray-700 rounded-lg px-4 py-3 text-luxury-white placeholder-luxury-white/50 focus:border-luxury-accent focus:outline-none transition-colors duration-300 peer resize-none"
                placeholder=" "
              />
              <label className="absolute left-4 top-3 text-luxury-white/50 transition-all duration-300 peer-focus:-translate-y-6 peer-focus:text-luxury-accent peer-focus:text-sm peer-[:not(:placeholder-shown)]:-translate-y-6 peer-[:not(:placeholder-shown)]:text-luxury-accent peer-[:not(:placeholder-shown)]:text-sm">
                Your Message
              </label>
            </div>

            <motion.button
              type="submit"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="w-full bg-luxury-accent text-luxury-black font-semibold py-4 rounded-lg relative overflow-hidden group glow-hover transition-all duration-300"
            >
              <span className="relative z-10 flex items-center justify-center gap-2">
                <Mail className="w-5 h-5" />
                Send Message
              </span>
              <div className="absolute inset-0 bg-luxury-glow opacity-0 group-hover:opacity-20 transition-opacity duration-300" />
            </motion.button>
          </form>

          <div className="mt-8 pt-8 border-t border-luxury-gray-700">
            <div className="flex justify-center gap-6">
              <motion.a
                href="mailto:hello@example.com"
                whileHover={{ scale: 1.1 }}
                className="p-3 bg-luxury-gray-800/50 rounded-full border border-luxury-gray-700 text-luxury-accent hover:border-luxury-accent transition-colors duration-300"
              >
                <Mail className="w-6 h-6" />
              </motion.a>
              <motion.a
                href="https://linkedin.com"
                whileHover={{ scale: 1.1 }}
                className="p-3 bg-luxury-gray-800/50 rounded-full border border-luxury-gray-700 text-luxury-accent hover:border-luxury-accent transition-colors duration-300"
              >
                <Linkedin className="w-6 h-6" />
              </motion.a>
              <motion.a
                href="https://github.com"
                whileHover={{ scale: 1.1 }}
                className="p-3 bg-luxury-gray-800/50 rounded-full border border-luxury-gray-700 text-luxury-accent hover:border-luxury-accent transition-colors duration-300"
              >
                <Github className="w-6 h-6" />
              </motion.a>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

const Footer: React.FC = () => {
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 500);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="relative py-16 px-8 border-t border-luxury-gray-800">
      <div className="max-w-7xl mx-auto">
        <div className="text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-8"
          >
            <h3 className="text-2xl font-bold text-luxury-white mb-4">
              Ready to start your project?
            </h3>
            <button className="text-luxury-accent hover:text-luxury-glow transition-colors duration-300 font-semibold">
              Get in touch →
            </button>
          </motion.div>

          <div className="w-full h-px bg-gradient-to-r from-transparent via-luxury-gray-700 to-transparent mb-8" />

          <div className="flex flex-col md:flex-row justify-between items-center text-luxury-white/60 font-mono text-sm">
            <p>© 2024 Your Name — All rights reserved</p>
            <p className="mt-2 md:mt-0">Crafted with precision and passion</p>
          </div>
        </div>
      </div>

      <motion.button
        initial={{ opacity: 0 }}
        animate={{ opacity: showScrollTop ? 1 : 0 }}
        onClick={scrollToTop}
        className="fixed bottom-8 right-8 p-3 bg-luxury-accent text-luxury-black rounded-full shadow-lg hover:scale-110 transition-all duration-300 z-50"
      >
        <ChevronUp className="w-6 h-6" />
      </motion.button>
    </footer>
  );
};

const Index: React.FC = () => {
  const [isAuthPanelOpen, setIsAuthPanelOpen] = useState(false);

  const toggleAuthPanel = () => {
    setIsAuthPanelOpen(!isAuthPanelOpen);
  };

  return (
    <div className="relative">
      <GeometricBackground />
      <Navigation onAuthToggle={toggleAuthPanel} />
      <AuthPanel isOpen={isAuthPanelOpen} onClose={() => setIsAuthPanelOpen(false)} />
      <GeometricHero />
      <AboutSection />
      <ServicesSection />
      <PortfolioSection />
      <TestimonialsCarousel />
      <ContactSection />
      <Footer />
    </div>
  );
};

export default Index;
