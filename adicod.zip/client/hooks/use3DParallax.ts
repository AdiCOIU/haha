import { useEffect, useRef, useState } from "react";
import { MotionValue, useMotionValue, useSpring, useTransform } from "framer-motion";

interface Use3DParallaxOptions {
  intensity?: number;
  scale?: number;
  rotationIntensity?: number;
  enableTilt?: boolean;
  enableScale?: boolean;
  enableGlow?: boolean;
}

export const use3DParallax = (options: Use3DParallaxOptions = {}) => {
  const {
    intensity = 0.3,
    scale = 1.05,
    rotationIntensity = 10,
    enableTilt = true,
    enableScale = true,
    enableGlow = false,
  } = options;

  const ref = useRef<HTMLElement>(null);
  const [bounds, setBounds] = useState<DOMRect | null>(null);

  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  const springConfig = { damping: 25, stiffness: 150, mass: 0.1 };
  const x = useSpring(mouseX, springConfig);
  const y = useSpring(mouseY, springConfig);

  const rotateX = useTransform(y, [0, 1], [rotationIntensity, -rotationIntensity]);
  const rotateY = useTransform(x, [0, 1], [-rotationIntensity, rotationIntensity]);
  const scaleValue = useTransform([x, y], ([latestX, latestY]) => {
    if (!enableScale) return 1;
    const distance = Math.sqrt(latestX * latestX + latestY * latestY);
    return 1 + (distance * scale - 1) * intensity;
  });

  // Set up event listeners once
  useEffect(() => {
    const element = ref.current;
    if (!element) return;

    const updateBounds = () => {
      setBounds(element.getBoundingClientRect());
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (!element) return;
      
      const rect = element.getBoundingClientRect();
      const relativeX = (e.clientX - rect.left) / rect.width;
      const relativeY = (e.clientY - rect.top) / rect.height;

      mouseX.set(relativeX);
      mouseY.set(relativeY);
    };

    const handleMouseLeave = () => {
      mouseX.set(0.5);
      mouseY.set(0.5);
    };

    // Initial bounds calculation
    updateBounds();
    
    // Set up event listeners
    element.addEventListener("mousemove", handleMouseMove);
    element.addEventListener("mouseleave", handleMouseLeave);
    window.addEventListener("resize", updateBounds);

    return () => {
      element.removeEventListener("mousemove", handleMouseMove);
      element.removeEventListener("mouseleave", handleMouseLeave);
      window.removeEventListener("resize", updateBounds);
    };
  }, []); // Empty dependency array - only run once

  return {
    ref,
    style: {
      rotateX: enableTilt ? rotateX : 0,
      rotateY: enableTilt ? rotateY : 0,
      scale: scaleValue,
      transformStyle: "preserve-3d" as const,
    },
    mouseX,
    mouseY,
  };
};

export const useMouseGlow = (intensity: number = 1) => {
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  const ref = useRef<HTMLElement>(null);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;

    const handleMouseMove = (e: MouseEvent) => {
      const rect = element.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 100;
      const y = ((e.clientY - rect.top) / rect.height) * 100;
      
      mouseX.set(x);
      mouseY.set(y);
    };

    const handleMouseLeave = () => {
      mouseX.set(50);
      mouseY.set(50);
    };

    element.addEventListener("mousemove", handleMouseMove);
    element.addEventListener("mouseleave", handleMouseLeave);

    return () => {
      element.removeEventListener("mousemove", handleMouseMove);
      element.removeEventListener("mouseleave", handleMouseLeave);
    };
  }, []); // Empty dependency array - only run once

  const glowStyle = useTransform(
    [mouseX, mouseY],
    ([x, y]) => ({
      background: `radial-gradient(circle at ${x}% ${y}%, rgba(249, 115, 22, ${0.1 * intensity}) 0%, transparent 70%)`,
    })
  );

  return { ref, glowStyle, mouseX, mouseY };
};
