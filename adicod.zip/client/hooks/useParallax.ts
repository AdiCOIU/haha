import { useScroll, useTransform } from "framer-motion";
import { RefObject } from "react";

interface ParallaxOptions {
  speed?: number;
  direction?: "up" | "down";
  range?: [number, number];
}

export const useParallax = (
  ref: RefObject<HTMLElement>,
  options: ParallaxOptions = {}
) => {
  const { speed = 0.5, direction = "up", range = [0, 1] } = options;
  
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });

  const multiplier = direction === "up" ? -speed : speed;
  const outputRange = [range[0] * 100 * multiplier, range[1] * 100 * multiplier];
  
  const y = useTransform(scrollYProgress, [0, 1], outputRange);
  const opacity = useTransform(scrollYProgress, [0, 0.2, 0.8, 1], [0, 1, 1, 0]);
  
  return { y, opacity, scrollYProgress };
};

export const useParallaxLayers = (
  ref: RefObject<HTMLElement>,
  layerCount: number = 3
) => {
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });

  const layers = Array.from({ length: layerCount }, (_, i) => {
    const speed = (i + 1) * 0.3;
    const y = useTransform(scrollYProgress, [0, 1], [0, -100 * speed]);
    return { y, speed };
  });

  return { layers, scrollYProgress };
};
