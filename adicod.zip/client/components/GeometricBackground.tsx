import React from "react";
import { motion } from "framer-motion";

const NetworkNode: React.FC<{ 
  x: number; 
  y: number; 
  delay?: number; 
  size?: number;
}> = ({ x, y, delay = 0, size = 3 }) => {
  return (
    <g>
      <circle
        cx={x}
        cy={y}
        r={size}
        fill="#f97316"
        className="opacity-60"
      >
        <animate
          attributeName="opacity"
          values="0.3;0.8;0.3"
          dur="3s"
          begin={`${delay}s`}
          repeatCount="indefinite"
        />
        <animate
          attributeName="r"
          values={`${size};${size + 1.5};${size}`}
          dur="3s"
          begin={`${delay}s`}
          repeatCount="indefinite"
        />
      </circle>
      <circle
        cx={x}
        cy={y}
        r={size + 8}
        fill="none"
        stroke="#ea580c"
        strokeWidth="0.5"
        className="opacity-20"
      >
        <animate
          attributeName="opacity"
          values="0;0.4;0"
          dur="3s"
          begin={`${delay}s`}
          repeatCount="indefinite"
        />
      </circle>
    </g>
  );
};

const DataStream: React.FC<{
  path: string;
  delay?: number;
  duration?: number;
}> = ({ path, delay = 0, duration = 8 }) => {
  return (
    <g>
      <path
        d={path}
        stroke="#1a1a1a"
        strokeWidth="1"
        fill="none"
        className="opacity-10"
      />
      <path
        d={path}
        stroke="#f97316"
        strokeWidth="2"
        fill="none"
        className="opacity-0"
        strokeDasharray="20 10"
      >
        <animate
          attributeName="stroke-dashoffset"
          values="0;-30"
          dur={`${duration}s`}
          begin={`${delay}s`}
          repeatCount="indefinite"
        />
        <animate
          attributeName="opacity"
          values="0;0.6;0"
          dur={`${duration}s`}
          begin={`${delay}s`}
          repeatCount="indefinite"
        />
      </path>
    </g>
  );
};

const DigitalGrid: React.FC = () => {
  const lines = [];
  const spacing = 80;
  const width = 1920;
  const height = 1080;

  // Create a subtle grid pattern
  for (let x = 0; x <= width; x += spacing) {
    lines.push(
      <line
        key={`v-${x}`}
        x1={x}
        y1={0}
        x2={x}
        y2={height}
        stroke="#0a0a0a"
        strokeWidth="0.5"
        className="opacity-8"
      />
    );
  }

  for (let y = 0; y <= height; y += spacing) {
    lines.push(
      <line
        key={`h-${y}`}
        x1={0}
        y1={y}
        x2={width}
        y2={y}
        stroke="#0a0a0a"
        strokeWidth="0.5"
        className="opacity-8"
      />
    );
  }

  return <g>{lines}</g>;
};

const GeometricBackground: React.FC = () => {
  const nodes = [
    { x: 1200, y: 200, delay: 0, size: 4 },
    { x: 1500, y: 350, delay: 0.5, size: 3 },
    { x: 1300, y: 500, delay: 1, size: 5 },
    { x: 1600, y: 650, delay: 1.5, size: 3 },
    { x: 1100, y: 400, delay: 0.3, size: 4 },
    { x: 1400, y: 750, delay: 0.8, size: 3 },
    { x: 1700, y: 300, delay: 1.3, size: 4 },
    { x: 1250, y: 650, delay: 0.6, size: 3 },
  ];

  const dataStreams = [
    "M 1000 200 Q 1200 300 1400 250 Q 1600 200 1800 300",
    "M 1000 400 L 1300 350 L 1600 400 L 1900 350",
    "M 1000 600 Q 1250 500 1500 600 Q 1750 700 2000 650",
    "M 1000 800 L 1200 750 L 1400 800 L 1600 750 L 1800 800",
  ];

  return (
    <div className="fixed inset-0 -z-10 overflow-hidden">
      {/* Pure black base */}
      <div className="absolute inset-0 bg-black" />
      
      {/* Main geometric shapes with angular cuts */}
      <div className="absolute inset-0">
        {/* Large diagonal orange accent */}
        <motion.div
          initial={{ x: -200, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 1.5, ease: "easeOut" }}
          className="absolute top-0 right-0 w-96 h-full bg-gradient-to-br from-orange-500/20 to-orange-600/10"
          style={{
            clipPath: "polygon(60% 0%, 100% 0%, 100% 100%, 20% 100%)",
          }}
        />

        {/* Secondary angular shape */}
        <motion.div
          initial={{ x: 200, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 1.5, ease: "easeOut", delay: 0.3 }}
          className="absolute top-0 right-0 w-80 h-full bg-gradient-to-br from-orange-400/15 to-transparent"
          style={{
            clipPath: "polygon(70% 0%, 100% 0%, 100% 100%, 40% 100%)",
          }}
        />

        {/* Animated cutting shape */}
        <motion.div
          animate={{
            clipPath: [
              "polygon(50% 0%, 100% 0%, 100% 100%, 30% 100%)",
              "polygon(55% 0%, 100% 0%, 100% 100%, 25% 100%)",
              "polygon(50% 0%, 100% 0%, 100% 100%, 30% 100%)",
            ],
          }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-0 right-0 w-72 h-full bg-gradient-to-br from-orange-300/10 to-orange-500/5"
        />
      </div>

      {/* IT Network Animation Layer */}
      <svg
        className="absolute inset-0 w-full h-full"
        viewBox="0 0 1920 1080"
        preserveAspectRatio="xMidYMid slice"
      >
        <defs>
          <filter id="orangeGlow">
            <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
            <feMerge> 
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
          
          <linearGradient id="streamGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#ea580c" stopOpacity="0.4" />
            <stop offset="50%" stopColor="#f97316" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#fb923c" stopOpacity="0.3" />
          </linearGradient>

          {/* Mask for geometric clipping */}
          <clipPath id="geometricClip">
            <polygon points="0,0 1920,0 1920,1080 800,1080 1200,600 600,400 0,800" />
          </clipPath>
        </defs>

        {/* Subtle grid background */}
        <g clipPath="url(#geometricClip)">
          <DigitalGrid />
        </g>

        {/* Data streams with geometric clipping */}
        <g clipPath="url(#geometricClip)">
          {dataStreams.map((path, index) => (
            <DataStream
              key={`stream-${index}`}
              path={path}
              delay={index * 0.5}
              duration={6 + index}
            />
          ))}
        </g>

        {/* Network nodes */}
        <g filter="url(#orangeGlow)">
          {nodes.map((node, index) => (
            <NetworkNode
              key={`node-${index}`}
              {...node}
            />
          ))}
        </g>

        {/* Flowing data particles */}
        <g filter="url(#orangeGlow)">
          {[0, 1, 2, 3].map((i) => (
            <circle
              key={`particle-${i}`}
              r="2"
              fill="url(#streamGradient)"
            >
              <animateMotion
                dur="15s"
                begin={`${i * 2}s`}
                repeatCount="indefinite"
                path="M 1000 300 Q 1300 200 1600 350 Q 1800 500 1900 400"
              />
              <animate
                attributeName="opacity"
                values="0;1;1;0"
                dur="15s"
                begin={`${i * 2}s`}
                repeatCount="indefinite"
              />
            </circle>
          ))}
        </g>
      </svg>

      {/* Additional angular overlay elements */}
      <div className="absolute inset-0 pointer-events-none">
        {/* Sharp diagonal cuts */}
        <motion.div
          animate={{
            opacity: [0.1, 0.3, 0.1],
          }}
          transition={{ duration: 6, repeat: Infinity }}
          className="absolute top-1/4 right-1/3 w-64 h-2 bg-orange-500 transform rotate-45"
          style={{
            clipPath: "polygon(0% 0%, 100% 0%, 90% 100%, 0% 100%)",
          }}
        />

        <motion.div
          animate={{
            opacity: [0.2, 0.4, 0.2],
          }}
          transition={{ duration: 8, repeat: Infinity, delay: 2 }}
          className="absolute bottom-1/3 right-1/4 w-48 h-1 bg-orange-400 transform -rotate-12"
          style={{
            clipPath: "polygon(10% 0%, 100% 0%, 100% 100%, 0% 100%)",
          }}
        />

        {/* Geometric accent elements */}
        <motion.div
          animate={{ 
            rotate: [0, 360],
            scale: [1, 1.1, 1]
          }}
          transition={{ 
            rotate: { duration: 20, repeat: Infinity, ease: "linear" },
            scale: { duration: 4, repeat: Infinity, ease: "easeInOut" }
          }}
          className="absolute top-1/2 right-1/4 w-16 h-16 border border-orange-500/30"
          style={{
            clipPath: "polygon(0% 0%, 100% 0%, 80% 100%, 20% 100%)",
          }}
        />
      </div>

      {/* Subtle ambient lighting */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-orange-500/10 rounded-full blur-3xl animate-pulse" 
             style={{ animationDuration: '8s' }} />
        <div className="absolute bottom-1/3 right-1/3 w-64 h-64 bg-orange-400/5 rounded-full blur-2xl animate-pulse" 
             style={{ animationDuration: '12s', animationDelay: '4s' }} />
      </div>

      {/* Final noise texture */}
      <div className="absolute inset-0 opacity-[0.01] mix-blend-overlay pointer-events-none noise" />
    </div>
  );
};

export default GeometricBackground;
