import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Sun, Moon } from "lucide-react";

interface DarkModeToggleProps {
  className?: string;
}

const DarkModeToggle: React.FC<DarkModeToggleProps> = ({ className = "" }) => {
  const [isDark, setIsDark] = useState(true); // Default to dark theme
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    
    // Check for saved theme preference or default to dark
    const savedTheme = localStorage.getItem("theme");
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    
    if (savedTheme) {
      setIsDark(savedTheme === "dark");
    } else {
      setIsDark(prefersDark);
    }
  }, []);

  useEffect(() => {
    if (!mounted) return;
    
    const root = document.documentElement;
    
    if (isDark) {
      root.classList.add("dark");
      root.style.setProperty("--theme-bg", "0 0% 0%");
      root.style.setProperty("--theme-text", "0 0% 98%");
      localStorage.setItem("theme", "dark");
    } else {
      root.classList.remove("dark");
      root.style.setProperty("--theme-bg", "0 0% 98%");
      root.style.setProperty("--theme-text", "0 0% 8%");
      localStorage.setItem("theme", "light");
    }
  }, [isDark, mounted]);

  const toggleTheme = () => {
    setIsDark(!isDark);
  };

  if (!mounted) {
    return (
      <div className={`w-14 h-8 rounded-full bg-luxury-gray-800 ${className}`} />
    );
  }

  return (
    <motion.button
      onClick={toggleTheme}
      className={`relative w-14 h-8 rounded-full p-1 transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-orange-500/50 ${
        isDark ? "bg-luxury-gray-800" : "bg-orange-200"
      } ${className}`}
      whileTap={{ scale: 0.95 }}
      aria-label={`Switch to ${isDark ? "light" : "dark"} mode`}
    >
      {/* Background track */}
      <motion.div
        className="absolute inset-1 rounded-full"
        animate={{
          backgroundColor: isDark ? "#1a1a1a" : "#fed7aa",
        }}
        transition={{ duration: 0.3 }}
      />

      {/* Slider */}
      <motion.div
        className="relative w-6 h-6 rounded-full shadow-lg flex items-center justify-center z-10"
        animate={{
          x: isDark ? 0 : 24,
          backgroundColor: isDark ? "#f97316" : "#ffffff",
          boxShadow: isDark 
            ? "0 0 12px rgba(249, 115, 22, 0.4)" 
            : "0 2px 8px rgba(0, 0, 0, 0.2)",
        }}
        transition={{
          type: "spring",
          stiffness: 500,
          damping: 30,
        }}
      >
        <motion.div
          animate={{
            scale: isDark ? 1 : 0,
            opacity: isDark ? 1 : 0,
          }}
          transition={{ duration: 0.2 }}
          className="absolute"
        >
          <Moon className="w-3 h-3 text-white" />
        </motion.div>
        
        <motion.div
          animate={{
            scale: isDark ? 0 : 1,
            opacity: isDark ? 0 : 1,
          }}
          transition={{ duration: 0.2 }}
          className="absolute"
        >
          <Sun className="w-3 h-3 text-orange-600" />
        </motion.div>
      </motion.div>

      {/* Glow effect */}
      <motion.div
        className="absolute inset-0 rounded-full"
        animate={{
          boxShadow: isDark 
            ? "0 0 20px rgba(249, 115, 22, 0.2)" 
            : "0 0 20px rgba(251, 146, 60, 0.1)",
        }}
        transition={{ duration: 0.3 }}
      />
    </motion.button>
  );
};

export default DarkModeToggle;
