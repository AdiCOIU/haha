import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight, Star, Quote, Play } from "lucide-react";
import { use3DParallax } from "../hooks/use3DParallax";

interface Testimonial {
  id: number;
  name: string;
  role: string;
  company: string;
  content: string;
  rating: number;
  avatar: string;
  hasVideo?: boolean;
  videoUrl?: string;
}

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: "Sarah Chen",
    role: "CTO",
    company: "TechFlow Solutions",
    content: "Exceptional work quality and attention to detail. The website exceeded our expectations with its premium design and flawless functionality.",
    rating: 5,
    avatar: "SC",
    hasVideo: true,
    videoUrl: "https://player.vimeo.com/video/placeholder",
  },
  {
    id: 2,
    name: "Marcus Rodriguez",
    role: "Creative Director",
    company: "Digital Innovations",
    content: "Outstanding technical expertise combined with creative vision. Delivered a cutting-edge solution that perfectly captured our brand identity.",
    rating: 5,
    avatar: "MR",
    hasVideo: false,
  },
  {
    id: 3,
    name: "Emily Watson",
    role: "Product Manager",
    company: "NextGen Startups",
    content: "Professional, efficient, and innovative. The project was completed ahead of schedule with remarkable quality and performance optimization.",
    rating: 5,
    avatar: "EW",
    hasVideo: true,
    videoUrl: "https://player.vimeo.com/video/placeholder2",
  },
  {
    id: 4,
    name: "David Kim",
    role: "Founder",
    company: "Apex Digital",
    content: "Incredible attention to user experience and modern design principles. The final product significantly improved our conversion rates.",
    rating: 5,
    avatar: "DK",
    hasVideo: false,
  },
];

const TestimonialsCarousel: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const [showVideo, setShowVideo] = useState(false);

  useEffect(() => {
    if (!isAutoPlaying) return;

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [isAutoPlaying]);

  const nextTestimonial = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const goToTestimonial = (index: number) => {
    setCurrentIndex(index);
  };

  const currentTestimonial = testimonials[currentIndex];

  return (
    <section className="relative py-32 px-8">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-luxury-white to-orange-400 bg-clip-text text-transparent">
            Client Testimonials
          </h2>
          <div className="w-16 h-px bg-orange-500 mx-auto mb-8" />
          <p className="text-xl text-luxury-white/70 max-w-2xl mx-auto">
            What our clients say about working with us.
          </p>
        </motion.div>

        <div
          className="relative"
          onMouseEnter={() => setIsAutoPlaying(false)}
          onMouseLeave={() => setIsAutoPlaying(true)}
        >
          {/* Main testimonial card */}
          <div className="relative h-96 overflow-hidden">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentTestimonial.id}
                initial={{ opacity: 0, x: 300, rotateY: 15 }}
                animate={{ opacity: 1, x: 0, rotateY: 0 }}
                exit={{ opacity: 0, x: -300, rotateY: -15 }}
                transition={{ duration: 0.6, ease: "easeInOut" }}
                className="absolute inset-0"
              >
                <div className="glass rounded-3xl p-8 md:p-12 h-full flex flex-col justify-between relative overflow-hidden border border-orange-500/20">
                  {/* Background gradient */}
                  <div className="absolute inset-0 bg-gradient-to-br from-orange-500/5 to-transparent" />
                  
                  {/* Quote icon */}
                  <motion.div
                    initial={{ scale: 0, rotate: -180 }}
                    animate={{ scale: 1, rotate: 0 }}
                    transition={{ delay: 0.3, duration: 0.6 }}
                    className="absolute top-6 right-6 opacity-20"
                  >
                    <Quote className="w-16 h-16 text-orange-500" />
                  </motion.div>

                  <div className="relative z-10">
                    {/* Rating stars */}
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.2, duration: 0.6 }}
                      className="flex items-center mb-6"
                    >
                      {[...Array(currentTestimonial.rating)].map((_, i) => (
                        <motion.div
                          key={i}
                          initial={{ opacity: 0, scale: 0 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: 0.4 + i * 0.1, duration: 0.3 }}
                        >
                          <Star className="w-5 h-5 text-orange-500 fill-current mr-1" />
                        </motion.div>
                      ))}
                    </motion.div>

                    {/* Testimonial content */}
                    <motion.p
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.3, duration: 0.8 }}
                      className="text-xl md:text-2xl text-luxury-white leading-relaxed mb-8 font-light"
                    >
                      "{currentTestimonial.content}"
                    </motion.p>
                  </div>

                  {/* Author info with video option */}
                  <motion.div
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5, duration: 0.8 }}
                    className="flex items-center justify-between relative z-10"
                  >
                    <div className="flex items-center">
                      <div className="relative mr-4">
                        <motion.div
                          className="w-16 h-16 rounded-full bg-gradient-to-br from-orange-500 to-orange-600 flex items-center justify-center text-white font-bold text-lg relative overflow-hidden cursor-pointer"
                          whileHover={{ scale: 1.1 }}
                          onClick={() => currentTestimonial.hasVideo && setShowVideo(!showVideo)}
                        >
                          {currentTestimonial.avatar}
                          {currentTestimonial.hasVideo && (
                            <motion.div
                              className="absolute inset-0 bg-black/50 flex items-center justify-center"
                              initial={{ opacity: 0 }}
                              whileHover={{ opacity: 1 }}
                              transition={{ duration: 0.2 }}
                            >
                              <div className="w-0 h-0 border-l-4 border-l-white border-t-2 border-t-transparent border-b-2 border-b-transparent ml-1" />
                            </motion.div>
                          )}
                          <motion.div
                            className="absolute inset-0 bg-white opacity-0"
                            whileHover={{ opacity: 0.1 }}
                            transition={{ duration: 0.3 }}
                          />
                        </motion.div>
                        <div className="absolute inset-0 rounded-full bg-orange-500 opacity-30 blur-md animate-pulse" />
                        {currentTestimonial.hasVideo && (
                          <motion.div
                            className="absolute -bottom-1 -right-1 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center"
                            animate={{ scale: [1, 1.2, 1] }}
                            transition={{ duration: 2, repeat: Infinity }}
                          >
                            <div className="w-2 h-2 bg-white rounded-full" />
                          </motion.div>
                        )}
                      </div>

                      <div>
                        <h4 className="text-lg font-semibold text-luxury-white mb-1">
                          {currentTestimonial.name}
                        </h4>
                        <p className="text-orange-400 font-medium">
                          {currentTestimonial.role}
                        </p>
                        <p className="text-luxury-white/60 text-sm">
                          {currentTestimonial.company}
                        </p>
                      </div>
                    </div>

                    {/* Video testimonial button */}
                    {currentTestimonial.hasVideo && (
                      <motion.button
                        onClick={() => setShowVideo(!showVideo)}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        className="px-4 py-2 bg-orange-500/20 border border-orange-500/50 text-orange-500 rounded-lg text-sm font-medium hover:bg-orange-500/30 transition-colors duration-200"
                      >
                        {showVideo ? "Hide Video" : "Watch Video"}
                      </motion.button>
                    )}
                  </motion.div>

                  {/* Video Section */}
                  <AnimatePresence>
                    {showVideo && currentTestimonial.hasVideo && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.5 }}
                        className="mt-6 overflow-hidden"
                      >
                        <div className="aspect-video bg-luxury-gray-800 rounded-lg overflow-hidden relative">
                          {/* Placeholder for video */}
                          <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-orange-500/20 to-orange-600/10">
                            <div className="text-center">
                              <motion.div
                                animate={{ rotate: 360 }}
                                transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                                className="w-12 h-12 border-2 border-orange-500 border-t-transparent rounded-full mx-auto mb-4"
                              />
                              <p className="text-luxury-white/60 text-sm">Video testimonial loading...</p>
                              <p className="text-luxury-white/40 text-xs mt-1">Feature demonstration</p>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Navigation buttons */}
          <div className="flex items-center justify-between mt-8">
            <motion.button
              onClick={prevTestimonial}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              className="p-3 rounded-full bg-luxury-gray-800 border border-orange-500/30 text-orange-500 hover:border-orange-500 hover:bg-orange-500/10 transition-all duration-300"
            >
              <ChevronLeft className="w-6 h-6" />
            </motion.button>

            {/* Dots indicator */}
            <div className="flex items-center space-x-3">
              {testimonials.map((_, index) => (
                <motion.button
                  key={index}
                  onClick={() => goToTestimonial(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    index === currentIndex
                      ? "bg-orange-500 scale-125"
                      : "bg-luxury-gray-700 hover:bg-orange-500/50"
                  }`}
                  whileHover={{ scale: 1.2 }}
                  whileTap={{ scale: 0.9 }}
                />
              ))}
            </div>

            <motion.button
              onClick={nextTestimonial}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              className="p-3 rounded-full bg-luxury-gray-800 border border-orange-500/30 text-orange-500 hover:border-orange-500 hover:bg-orange-500/10 transition-all duration-300"
            >
              <ChevronRight className="w-6 h-6" />
            </motion.button>
          </div>
        </div>

        {/* Background decorative elements */}
        <div className="absolute top-1/2 left-1/4 transform -translate-y-1/2 -translate-x-1/2">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            className="w-32 h-32 border border-orange-500/10 rounded-full"
          />
        </div>
        
        <div className="absolute top-1/3 right-1/4 transform -translate-y-1/2 translate-x-1/2">
          <motion.div
            animate={{ rotate: -360 }}
            transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
            className="w-24 h-24 border border-orange-500/10 rounded-full"
          />
        </div>
      </div>
    </section>
  );
};

export default TestimonialsCarousel;
