import React from "react";
import { motion } from "framer-motion";
import { ArrowDown, ArrowRight } from "lucide-react";
import { use3DParallax, useMouseGlow } from "../hooks/use3DParallax";
import { TypewriterText, GlowText, AnimatedCounter, TextShimmer } from "./AnimatedText";

const GeometricHero: React.FC = () => {
  const heroParallax = use3DParallax({ intensity: 0.2, enableTilt: true, enableScale: false });
  const buttonParallax = use3DParallax({ intensity: 0.4, scale: 1.05 });

  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Left side content */}
      <div className="relative z-20 w-full lg:w-1/2 px-8 lg:px-16 xl:px-24">
        {/* Subtle light sweep effect */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <motion.div
            animate={{
              y: ['-100%', '100%'],
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              ease: 'linear',
            }}
            className="absolute left-0 w-full h-32 bg-gradient-to-b from-transparent via-orange-500/5 to-transparent transform -skew-y-12"
            style={{
              filter: 'blur(1px)',
            }}
          />

          {/* Secondary sweep with different timing */}
          <motion.div
            animate={{
              y: ['-120%', '120%'],
            }}
            transition={{
              duration: 12,
              repeat: Infinity,
              ease: 'linear',
              delay: 4,
            }}
            className="absolute left-0 w-full h-24 bg-gradient-to-b from-transparent via-orange-400/3 to-transparent transform skew-y-6"
            style={{
              filter: 'blur(2px)',
            }}
          />
        </div>
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="max-w-2xl relative z-10"
        >
          {/* Category label */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="mb-6"
          >
            <span className="text-orange-500 text-sm font-semibold tracking-wider uppercase">
              Digital Innovation
            </span>
            <div className="w-16 h-px bg-orange-500 mt-2" />
          </motion.div>

          {/* Main heading with enhanced animations */}
          <motion.div
            ref={heroParallax.ref}
            style={heroParallax.style}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="text-5xl lg:text-7xl xl:text-8xl font-bold leading-tight mb-8 perspective-1000"
          >
            <GlowText className="block text-luxury-white">
              <TypewriterText text="PREMIUM" delay={800} speed={100} showCursor={false} />
            </GlowText>
            <GlowText className="block text-luxury-white">
              <TypewriterText text="DIGITAL" delay={1500} speed={100} showCursor={false} />
            </GlowText>
            <TextShimmer className="block bg-gradient-to-r from-orange-500 to-orange-400 bg-clip-text text-transparent">
              <TypewriterText text="SOLUTIONS" delay={2200} speed={100} showCursor={false} />
            </TextShimmer>
          </motion.div>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8, duration: 0.6 }}
            className="text-xl lg:text-2xl text-luxury-white/80 leading-relaxed mb-12 max-w-lg"
          >
            Crafting exceptional web experiences with cutting-edge technology and innovative design solutions.
          </motion.p>

          {/* Enhanced CTA Buttons with 3D effects */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1, duration: 0.8 }}
            className="flex flex-col sm:flex-row gap-6"
          >
            <motion.button
              ref={buttonParallax.ref}
              style={buttonParallax.style}
              whileHover={{
                scale: 1.05,
                x: 5,
                boxShadow: "0 20px 40px rgba(249, 115, 22, 0.4)",
                rotateX: 5,
                rotateY: 5,
              }}
              whileTap={{ scale: 0.95 }}
              className="group relative px-8 py-4 bg-orange-500 text-black font-semibold rounded-none overflow-hidden transition-all duration-300 transform-gpu"
              style={{
                clipPath: "polygon(0% 0%, 90% 0%, 100% 100%, 10% 100%)",
                transformStyle: "preserve-3d",
              }}
            >
              <span className="relative z-10 flex items-center gap-2">
                VIEW PORTFOLIO
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
              </span>
              <motion.div
                className="absolute inset-0 bg-orange-400"
                initial={{ x: "-100%" }}
                whileHover={{ x: "0%" }}
                transition={{ duration: 0.3 }}
              />
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent"
                animate={{ x: ["-100%", "100%"] }}
                transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
              />
            </motion.button>

            <motion.button
              whileHover={{
                scale: 1.05,
                x: 5,
                boxShadow: "0 20px 40px rgba(249, 115, 22, 0.2)",
                backgroundColor: "#f97316",
                color: "#000",
              }}
              whileTap={{ scale: 0.95 }}
              className="group relative px-8 py-4 bg-transparent border-2 border-orange-500 text-orange-500 font-semibold transition-all duration-300"
              style={{
                clipPath: "polygon(0% 0%, 90% 0%, 100% 100%, 10% 100%)",
              }}
            >
              <span className="relative z-10 flex items-center gap-2">
                GET IN TOUCH
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
              </span>
            </motion.button>
          </motion.div>

          {/* Enhanced Stats with animated counters */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.2, duration: 0.6 }}
            className="mt-16 flex gap-12 relative"
          >
            <div className="absolute inset-0 rounded-lg pointer-events-none bg-gradient-to-r from-orange-500/5 via-orange-400/10 to-orange-500/5 opacity-50" />
            <motion.div
              whileHover={{ scale: 1.1, y: -5 }}
              className="relative z-10 text-center"
            >
              <div className="text-3xl font-bold text-orange-500">
                <AnimatedCounter from={0} to={5} duration={2} delay={1.5} suffix="+" />
              </div>
              <div className="text-sm text-luxury-white/60 uppercase tracking-wider">Years Experience</div>
            </motion.div>
            <motion.div
              whileHover={{ scale: 1.1, y: -5 }}
              className="relative z-10 text-center"
            >
              <div className="text-3xl font-bold text-orange-500">
                <AnimatedCounter from={0} to={50} duration={2.5} delay={2} suffix="+" />
              </div>
              <div className="text-sm text-luxury-white/60 uppercase tracking-wider">Projects Completed</div>
            </motion.div>
            <motion.div
              whileHover={{ scale: 1.1, y: -5 }}
              className="relative z-10 text-center"
            >
              <div className="text-3xl font-bold text-orange-500">
                <AnimatedCounter from={0} to={100} duration={3} delay={2.5} suffix="%" />
              </div>
              <div className="text-sm text-luxury-white/60 uppercase tracking-wider">Client Satisfaction</div>
            </motion.div>
          </motion.div>
        </motion.div>

        {/* Scroll indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5, duration: 1 }}
          className="absolute bottom-8 left-8 lg:left-16 xl:left-24"
        >
          <div className="flex flex-col items-center text-luxury-white/50">
            <span className="text-xs font-mono mb-2 rotate-90 origin-center">SCROLL</span>
            <motion.div
              animate={{ y: [0, 10, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <ArrowDown className="w-4 h-4" />
            </motion.div>
          </div>
        </motion.div>
      </div>

      {/* Right side geometric overlay area */}
      <div className="absolute inset-0 lg:relative lg:w-1/2 lg:h-screen">
        {/* Angular cutting shapes that reveal the background */}
        <motion.div
          initial={{ x: 100, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 1.2, ease: "easeOut", delay: 0.5 }}
          className="absolute inset-0 bg-black/40"
          style={{
            clipPath: "polygon(0% 0%, 60% 0%, 80% 100%, 20% 100%)",
          }}
        />

        <motion.div
          initial={{ x: 150, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 1.2, ease: "easeOut", delay: 0.7 }}
          className="absolute inset-0 bg-gradient-to-br from-orange-500/20 to-transparent"
          style={{
            clipPath: "polygon(10% 0%, 70% 0%, 90% 100%, 30% 100%)",
          }}
        />

        <motion.div
          initial={{ x: 200, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 1.2, ease: "easeOut", delay: 0.9 }}
          className="absolute inset-0 bg-black/60"
          style={{
            clipPath: "polygon(20% 0%, 80% 0%, 100% 100%, 40% 100%)",
          }}
        />

        {/* Dynamic geometric elements */}
        <motion.div
          animate={{
            clipPath: [
              "polygon(30% 0%, 90% 0%, 100% 100%, 50% 100%)",
              "polygon(25% 0%, 95% 0%, 100% 100%, 45% 100%)",
              "polygon(30% 0%, 90% 0%, 100% 100%, 50% 100%)",
            ],
          }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
          className="absolute inset-0 bg-gradient-to-br from-orange-400/10 to-orange-600/5"
        />

        {/* Floating geometric accent */}
        <motion.div
          animate={{ 
            rotate: [0, 360],
            scale: [1, 1.2, 1]
          }}
          transition={{ 
            rotate: { duration: 20, repeat: Infinity, ease: "linear" },
            scale: { duration: 6, repeat: Infinity, ease: "easeInOut" }
          }}
          className="absolute top-1/4 right-1/4 w-24 h-24 border-2 border-orange-500/40"
          style={{
            clipPath: "polygon(0% 0%, 100% 0%, 80% 100%, 20% 100%)",
          }}
        />

        <motion.div
          animate={{ 
            rotate: [360, 0],
            y: [0, -20, 0]
          }}
          transition={{ 
            rotate: { duration: 15, repeat: Infinity, ease: "linear" },
            y: { duration: 4, repeat: Infinity, ease: "easeInOut" }
          }}
          className="absolute bottom-1/3 right-1/3 w-16 h-16 bg-orange-500/20"
          style={{
            clipPath: "polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)",
          }}
        />
      </div>

      {/* Subtle gradient overlay for text readability */}
      <div className="absolute inset-0 bg-gradient-to-r from-black via-black/60 to-transparent lg:from-black lg:via-black/40 lg:to-transparent z-10" />
    </section>
  );
};

export default GeometricHero;
