import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, LogIn } from "lucide-react";
import DarkModeToggle from "./DarkModeToggle";

const NavLink: React.FC<{
  to: string;
  children: React.ReactNode;
  isActive: boolean;
  onClick?: () => void;
}> = ({ to, children, isActive, onClick }) => {
  return (
    <Link
      to={to}
      onClick={onClick}
      className="relative group px-4 py-2 text-luxury-white/80 hover:text-luxury-white transition-colors duration-300"
    >
      <span className="relative z-10 font-medium">{children}</span>
      
      {/* Hover effect */}
      <motion.div
        className="absolute inset-0 rounded-lg bg-luxury-accent/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
        whileHover={{ scale: 1.05 }}
        transition={{ type: "spring", stiffness: 400, damping: 25 }}
      />
      
      {/* Active underline */}
      <motion.div
        className="absolute bottom-0 left-1/2 h-0.5 bg-luxury-accent rounded-full"
        initial={false}
        animate={{
          width: isActive ? "80%" : "0%",
          x: "-50%",
        }}
        transition={{ duration: 0.3, ease: "easeInOut" }}
      />
      
      {/* Hover underline */}
      <motion.div
        className="absolute bottom-0 left-1/2 h-0.5 bg-luxury-white/50 rounded-full opacity-0 group-hover:opacity-100"
        initial={{ width: "0%", x: "-50%" }}
        whileHover={{ width: isActive ? "0%" : "60%" }}
        transition={{ duration: 0.3, ease: "easeInOut" }}
      />
    </Link>
  );
};

const Logo: React.FC = () => {
  return (
    <Link to="/" className="group flex items-center space-x-2">
      <motion.div
        className="relative w-10 h-10 rounded-lg bg-gradient-to-br from-luxury-accent to-luxury-glow flex items-center justify-center"
        whileHover={{ scale: 1.05, rotate: 5 }}
        transition={{ type: "spring", stiffness: 400, damping: 25 }}
      >
        <div className="w-6 h-6 border-2 border-white rounded-sm relative">
          <motion.div
            className="absolute top-1 left-1 w-1 h-1 bg-white rounded-full"
            animate={{ opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
          <motion.div
            className="absolute bottom-1 right-1 w-1 h-1 bg-white rounded-full"
            animate={{ opacity: [1, 0.5, 1] }}
            transition={{ duration: 2, repeat: Infinity, delay: 1 }}
          />
        </div>
        
        {/* Glow effect */}
        <motion.div
          className="absolute inset-0 rounded-lg bg-luxury-accent opacity-0 group-hover:opacity-30 blur-md"
          whileHover={{ scale: 1.2 }}
          transition={{ duration: 0.3 }}
        />
      </motion.div>
      
      <motion.span
        className="text-xl font-bold bg-gradient-to-r from-luxury-white to-luxury-accent bg-clip-text text-transparent"
        whileHover={{ scale: 1.02 }}
        transition={{ type: "spring", stiffness: 400, damping: 25 }}
      >
        Portfolio
      </motion.span>
    </Link>
  );
};

interface NavigationProps {
  onAuthToggle?: () => void;
}

const Navigation: React.FC<NavigationProps> = ({ onAuthToggle }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  const navItems = [
    { name: "Home", path: "/" },
    { name: "About", path: "/about" },
    { name: "Portfolio", path: "/portfolio" },
    { name: "Contact", path: "/contact" },
  ];

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      <motion.nav
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled
            ? "bg-luxury-black/80 backdrop-blur-md border-b border-luxury-gray-800/50"
            : "bg-transparent"
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <Logo />

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-2">
              {navItems.map((item) => (
                <NavLink
                  key={item.name}
                  to={item.path}
                  isActive={location.pathname === item.path}
                >
                  {item.name}
                </NavLink>
              ))}

              {/* Auth and Dark mode toggle */}
              <div className="flex items-center ml-4 pl-4 border-l border-luxury-gray-700 space-x-3">
                <motion.button
                  onClick={onAuthToggle}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="p-2 rounded-lg bg-orange-500/10 border border-orange-500/30 text-orange-500 hover:border-orange-500 hover:bg-orange-500/20 transition-all duration-300"
                >
                  <LogIn className="w-5 h-5" />
                </motion.button>
                <DarkModeToggle />
              </div>
            </div>

            {/* Mobile Menu Button */}
            <motion.button
              onClick={toggleMobileMenu}
              className="md:hidden p-2 rounded-lg bg-luxury-gray-800/50 backdrop-blur-sm border border-luxury-gray-700 text-luxury-white hover:border-luxury-accent transition-colors duration-300"
              whileTap={{ scale: 0.95 }}
            >
              <AnimatePresence mode="wait">
                {isMobileMenuOpen ? (
                  <motion.div
                    key="close"
                    initial={{ rotate: -90, opacity: 0 }}
                    animate={{ rotate: 0, opacity: 1 }}
                    exit={{ rotate: 90, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <X className="w-6 h-6" />
                  </motion.div>
                ) : (
                  <motion.div
                    key="menu"
                    initial={{ rotate: 90, opacity: 0 }}
                    animate={{ rotate: 0, opacity: 1 }}
                    exit={{ rotate: -90, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <Menu className="w-6 h-6" />
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.button>
          </div>
        </div>
      </motion.nav>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="fixed inset-0 bg-luxury-black/80 backdrop-blur-md z-40 md:hidden"
              onClick={closeMobileMenu}
            />

            {/* Mobile Menu */}
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="fixed top-20 right-0 bottom-0 w-80 bg-luxury-gray-900/95 backdrop-blur-xl border-l border-luxury-gray-800 z-50 md:hidden"
            >
              <div className="flex flex-col p-6 space-y-4">
                {navItems.map((item, index) => (
                  <motion.div
                    key={item.name}
                    initial={{ x: 50, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: index * 0.1, duration: 0.3 }}
                  >
                    <NavLink
                      to={item.path}
                      isActive={location.pathname === item.path}
                      onClick={closeMobileMenu}
                    >
                      <span className="block text-lg">{item.name}</span>
                    </NavLink>
                  </motion.div>
                ))}

                {/* Mobile Menu Footer */}
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.4, duration: 0.3 }}
                  className="mt-auto pt-8"
                >
                  <div className="flex items-center justify-center space-x-4 mb-6">
                    <motion.button
                      onClick={() => {
                        onAuthToggle?.();
                        closeMobileMenu();
                      }}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-4 py-2 bg-orange-500 text-black font-medium rounded-lg hover:bg-orange-400 transition-colors duration-200"
                    >
                      Sign In
                    </motion.button>
                    <DarkModeToggle />
                  </div>
                  <div className="w-full h-px bg-gradient-to-r from-transparent via-luxury-gray-700 to-transparent mb-6" />
                  <p className="text-luxury-white/60 text-sm text-center">
                    Premium Digital Experiences
                  </p>
                </motion.div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
};

export default Navigation;
