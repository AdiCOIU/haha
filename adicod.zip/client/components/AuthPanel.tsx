import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Mail, Lock, User, Eye, EyeOff } from "lucide-react";

interface AuthPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

const AuthPanel: React.FC<AuthPanelProps> = ({ isOpen, onClose }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  
  const [loginData, setLoginData] = useState({
    email: "",
    password: "",
  });
  
  const [signupData, setSignupData] = useState({
    email: "",
    password: "",
    confirmPassword: "",
  });

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Login:", loginData);
    // Handle login logic here
  };

  const handleSignupSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Signup:", signupData);
    // Handle signup logic here
  };

  const switchToSignup = () => {
    setIsLogin(false);
  };

  const switchToLogin = () => {
    setIsLogin(true);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40"
            onClick={onClose}
          />

          {/* Slide Panel */}
          <motion.div
            initial={{ x: "-100%" }}
            animate={{ x: 0 }}
            exit={{ x: "-100%" }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="fixed left-0 top-0 h-full w-96 bg-black border-r border-orange-500/20 z-50 overflow-y-auto"
          >
            {/* Panel Header */}
            <div className="relative p-6 border-b border-luxury-gray-800">
              <button
                onClick={onClose}
                className="absolute top-6 right-6 p-2 rounded-full hover:bg-luxury-gray-800 transition-colors duration-200"
              >
                <X className="w-5 h-5 text-luxury-white/70 hover:text-luxury-white" />
              </button>
              
              <motion.h2
                key={isLogin ? "login" : "signup"}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="text-2xl font-bold text-luxury-white mb-2"
              >
                {isLogin ? "Welcome Back" : "Create Account"}
              </motion.h2>
              
              <p className="text-luxury-white/60">
                {isLogin 
                  ? "Sign in to access your premium portfolio" 
                  : "Join our exclusive platform"}
              </p>
            </div>

            {/* Form Container */}
            <div className="p-6">
              <AnimatePresence mode="wait">
                {isLogin ? (
                  <motion.form
                    key="login"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ duration: 0.3 }}
                    onSubmit={handleLoginSubmit}
                    className="space-y-6"
                  >
                    {/* Email Field */}
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-luxury-white/80">
                        Email Address
                      </label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-luxury-white/40" />
                        <input
                          type="email"
                          value={loginData.email}
                          onChange={(e) => setLoginData({ ...loginData, email: e.target.value })}
                          className="w-full pl-12 pr-4 py-3 bg-luxury-gray-800 border border-luxury-gray-700 rounded-lg text-luxury-white placeholder-luxury-white/40 focus:border-orange-500 focus:outline-none transition-colors duration-200"
                          placeholder="Enter your email"
                          required
                        />
                      </div>
                    </div>

                    {/* Password Field */}
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-luxury-white/80">
                        Password
                      </label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-luxury-white/40" />
                        <input
                          type={showPassword ? "text" : "password"}
                          value={loginData.password}
                          onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                          className="w-full pl-12 pr-12 py-3 bg-luxury-gray-800 border border-luxury-gray-700 rounded-lg text-luxury-white placeholder-luxury-white/40 focus:border-orange-500 focus:outline-none transition-colors duration-200"
                          placeholder="Enter your password"
                          required
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 transform -translate-y-1/2 text-luxury-white/40 hover:text-luxury-white transition-colors duration-200"
                        >
                          {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                        </button>
                      </div>
                    </div>

                    {/* Login Button */}
                    <motion.button
                      type="submit"
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      className="w-full py-3 bg-orange-500 text-black font-semibold rounded-lg hover:bg-orange-400 transition-colors duration-200 relative overflow-hidden"
                    >
                      <span className="relative z-10">Sign In</span>
                      <motion.div
                        className="absolute inset-0 bg-orange-400"
                        initial={{ x: "-100%" }}
                        whileHover={{ x: "0%" }}
                        transition={{ duration: 0.3 }}
                      />
                    </motion.button>

                    {/* Switch to Signup */}
                    <div className="text-center">
                      <span className="text-luxury-white/60">Don't have an account? </span>
                      <button
                        type="button"
                        onClick={switchToSignup}
                        className="text-orange-500 hover:text-orange-400 font-medium transition-colors duration-200"
                      >
                        Sign up
                      </button>
                    </div>
                  </motion.form>
                ) : (
                  <motion.form
                    key="signup"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ duration: 0.3 }}
                    onSubmit={handleSignupSubmit}
                    className="space-y-6"
                  >
                    {/* Email Field */}
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-luxury-white/80">
                        Email Address
                      </label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-luxury-white/40" />
                        <input
                          type="email"
                          value={signupData.email}
                          onChange={(e) => setSignupData({ ...signupData, email: e.target.value })}
                          className="w-full pl-12 pr-4 py-3 bg-luxury-gray-800 border border-luxury-gray-700 rounded-lg text-luxury-white placeholder-luxury-white/40 focus:border-orange-500 focus:outline-none transition-colors duration-200"
                          placeholder="Enter your email"
                          required
                        />
                      </div>
                    </div>

                    {/* Password Field */}
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-luxury-white/80">
                        Password
                      </label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-luxury-white/40" />
                        <input
                          type={showPassword ? "text" : "password"}
                          value={signupData.password}
                          onChange={(e) => setSignupData({ ...signupData, password: e.target.value })}
                          className="w-full pl-12 pr-12 py-3 bg-luxury-gray-800 border border-luxury-gray-700 rounded-lg text-luxury-white placeholder-luxury-white/40 focus:border-orange-500 focus:outline-none transition-colors duration-200"
                          placeholder="Create a password"
                          required
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 transform -translate-y-1/2 text-luxury-white/40 hover:text-luxury-white transition-colors duration-200"
                        >
                          {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                        </button>
                      </div>
                    </div>

                    {/* Confirm Password Field */}
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-luxury-white/80">
                        Confirm Password
                      </label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-luxury-white/40" />
                        <input
                          type={showConfirmPassword ? "text" : "password"}
                          value={signupData.confirmPassword}
                          onChange={(e) => setSignupData({ ...signupData, confirmPassword: e.target.value })}
                          className="w-full pl-12 pr-12 py-3 bg-luxury-gray-800 border border-luxury-gray-700 rounded-lg text-luxury-white placeholder-luxury-white/40 focus:border-orange-500 focus:outline-none transition-colors duration-200"
                          placeholder="Confirm your password"
                          required
                        />
                        <button
                          type="button"
                          onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                          className="absolute right-3 top-1/2 transform -translate-y-1/2 text-luxury-white/40 hover:text-luxury-white transition-colors duration-200"
                        >
                          {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                        </button>
                      </div>
                    </div>

                    {/* Signup Button */}
                    <motion.button
                      type="submit"
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      className="w-full py-3 bg-orange-500 text-black font-semibold rounded-lg hover:bg-orange-400 transition-colors duration-200 relative overflow-hidden"
                    >
                      <span className="relative z-10">Create Account</span>
                      <motion.div
                        className="absolute inset-0 bg-orange-400"
                        initial={{ x: "-100%" }}
                        whileHover={{ x: "0%" }}
                        transition={{ duration: 0.3 }}
                      />
                    </motion.button>

                    {/* Switch to Login */}
                    <div className="text-center">
                      <span className="text-luxury-white/60">Already have an account? </span>
                      <button
                        type="button"
                        onClick={switchToLogin}
                        className="text-orange-500 hover:text-orange-400 font-medium transition-colors duration-200"
                      >
                        Sign in
                      </button>
                    </div>
                  </motion.form>
                )}
              </AnimatePresence>
            </div>

            {/* Panel Footer */}
            <div className="p-6 border-t border-luxury-gray-800">
              <p className="text-xs text-luxury-white/40 text-center">
                By continuing, you agree to our Terms of Service and Privacy Policy
              </p>
            </div>

            {/* Decorative Elements */}
            <div className="absolute top-1/2 right-0 transform translate-x-1/2 -translate-y-1/2">
              <div className="w-32 h-px bg-gradient-to-r from-orange-500/50 to-transparent" />
            </div>
            
            <div className="absolute bottom-1/4 right-4">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                className="w-8 h-8 border border-orange-500/20 rounded-sm"
              />
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default AuthPanel;
