import React, { useEffect, useState, useRef, useCallback } from "react";
import { motion, useSpring } from "framer-motion";

type CursorState = "default" | "hover" | "click" | "text" | "loading";

const EnhancedCursor: React.FC = () => {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [cursorState, setCursorState] = useState<CursorState>("default");
  const [isVisible, setIsVisible] = useState(false);
  const [trail, setTrail] = useState<Array<{ x: number; y: number; id: number }>>([]);
  const trailIdRef = useRef(0);
  const cursorStateRef = useRef<CursorState>("default");

  const springConfig = { damping: 25, stiffness: 700, mass: 0.5 };
  const cursorX = useSpring(0, springConfig);
  const cursorY = useSpring(0, springConfig);

  // Update ref when state changes
  useEffect(() => {
    cursorStateRef.current = cursorState;
  }, [cursorState]);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    const newX = e.clientX;
    const newY = e.clientY;
    
    setMousePosition({ x: newX, y: newY });
    cursorX.set(newX);
    cursorY.set(newY);
    setIsVisible(true);

    // Add trail point
    setTrail(prev => [
      ...prev.slice(-8), // Keep last 8 points
      { x: newX, y: newY, id: trailIdRef.current++ }
    ]);
  }, [cursorX, cursorY]);

  const handleMouseLeave = useCallback(() => setIsVisible(false), []);
  const handleMouseEnter = useCallback(() => setIsVisible(true), []);

  const handleMouseOver = useCallback((e: MouseEvent) => {
    const target = e.target as HTMLElement;
    
    if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable) {
      setCursorState("text");
    } else if (target.closest("button, a, [role='button']")) {
      setCursorState("hover");
    } else {
      setCursorState("default");
    }
  }, []);

  const handleMouseDown = useCallback(() => setCursorState("click"), []);
  const handleMouseUp = useCallback(() => {
    setCursorState(cursorStateRef.current === "click" ? "default" : cursorStateRef.current);
  }, []);

  useEffect(() => {
    document.addEventListener("mousemove", handleMouseMove);
    document.addEventListener("mouseleave", handleMouseLeave);
    document.addEventListener("mouseenter", handleMouseEnter);
    document.addEventListener("mouseover", handleMouseOver);
    document.addEventListener("mousedown", handleMouseDown);
    document.addEventListener("mouseup", handleMouseUp);

    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseleave", handleMouseLeave);
      document.removeEventListener("mouseenter", handleMouseEnter);
      document.removeEventListener("mouseover", handleMouseOver);
      document.removeEventListener("mousedown", handleMouseDown);
      document.removeEventListener("mouseup", handleMouseUp);
    };
  }, [handleMouseMove, handleMouseLeave, handleMouseEnter, handleMouseOver, handleMouseDown, handleMouseUp]);

  // Hide on mobile devices
  useEffect(() => {
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
      navigator.userAgent
    );
    
    if (isMobile) {
      setIsVisible(false);
    }
  }, []);

  const getCursorStyle = () => {
    const baseStyle = {
      x: mousePosition.x - 12,
      y: mousePosition.y - 12,
    };

    switch (cursorState) {
      case "hover":
        return {
          ...baseStyle,
          scale: 1.5,
          backgroundColor: "#f97316",
          border: "2px solid #ea580c",
        };
      case "click":
        return {
          ...baseStyle,
          scale: 0.8,
          backgroundColor: "#ea580c",
          border: "2px solid #c2410c",
        };
      case "text":
        return {
          ...baseStyle,
          scale: 1.2,
          backgroundColor: "transparent",
          border: "2px solid #f97316",
          borderRadius: "2px",
          width: "2px",
          height: "20px",
        };
      default:
        return {
          ...baseStyle,
          scale: 1,
          backgroundColor: "rgba(249, 115, 22, 0.8)",
          border: "2px solid rgba(249, 115, 22, 0.4)",
        };
    }
  };

  const getTrailStyle = () => {
    switch (cursorState) {
      case "hover":
        return {
          scale: 2,
          backgroundColor: "rgba(249, 115, 22, 0.3)",
          border: "1px solid rgba(249, 115, 22, 0.6)",
        };
      case "click":
        return {
          scale: 0.5,
          backgroundColor: "rgba(234, 88, 12, 0.6)",
          border: "1px solid rgba(194, 65, 12, 0.8)",
        };
      default:
        return {
          scale: 1.5,
          backgroundColor: "rgba(249, 115, 22, 0.2)",
          border: "1px solid rgba(249, 115, 22, 0.3)",
        };
    }
  };

  if (!isVisible) return null;

  return (
    <>
      {/* Trail effect */}
      {trail.map((point, index) => (
        <motion.div
          key={point.id}
          className="fixed pointer-events-none z-[9997] rounded-full mix-blend-screen"
          style={{
            x: point.x - 8,
            y: point.y - 8,
            width: 16,
            height: 16,
          }}
          initial={{ opacity: 0.8, scale: 0.5 }}
          animate={{
            opacity: 0,
            scale: 1.2,
            ...getTrailStyle(),
          }}
          transition={{
            duration: 0.6,
            ease: "easeOut",
          }}
        />
      ))}

      {/* Main cursor */}
      <motion.div
        className="fixed pointer-events-none z-[9999] rounded-full mix-blend-difference"
        style={{
          width: 24,
          height: 24,
        }}
        animate={getCursorStyle()}
        transition={{
          type: "spring",
          stiffness: 500,
          damping: 28,
          mass: 0.5,
        }}
      >
        {/* Inner dot */}
        <motion.div
          className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-1 h-1 bg-white rounded-full"
          animate={{
            scale: cursorState === "click" ? 2 : 1,
            opacity: cursorState === "text" ? 0 : 1,
          }}
        />

        {/* Loading animation for certain states */}
        {cursorState === "hover" && (
          <motion.div
            className="absolute inset-0 border-2 border-transparent border-t-white rounded-full"
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          />
        )}

        {/* Glow effect */}
        <motion.div
          className="absolute inset-0 rounded-full"
          animate={{
            boxShadow: cursorState === "hover" 
              ? "0 0 20px rgba(249, 115, 22, 0.8)" 
              : "0 0 10px rgba(249, 115, 22, 0.4)",
          }}
          transition={{ duration: 0.2 }}
        />
      </motion.div>

      {/* Outer ring for interactive elements */}
      {(cursorState === "hover" || cursorState === "click") && (
        <motion.div
          className="fixed pointer-events-none z-[9998] rounded-full border border-orange-500/50"
          style={{
            x: mousePosition.x - 20,
            y: mousePosition.y - 20,
            width: 40,
            height: 40,
          }}
          initial={{ scale: 0, opacity: 0 }}
          animate={{ 
            scale: cursorState === "click" ? 0.8 : 1, 
            opacity: 1,
            rotate: cursorState === "hover" ? 360 : 0,
          }}
          exit={{ scale: 0, opacity: 0 }}
          transition={{
            type: "spring",
            stiffness: 300,
            damping: 20,
            rotate: { duration: 2, repeat: Infinity, ease: "linear" },
          }}
        />
      )}
    </>
  );
};

export default EnhancedCursor;
