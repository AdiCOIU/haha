import React from "react";

const NetworkNode: React.FC<{ 
  x: number; 
  y: number; 
  delay?: number; 
  size?: number;
}> = ({ x, y, delay = 0, size = 4 }) => {
  return (
    <g>
      <circle
        cx={x}
        cy={y}
        r={size}
        fill="#f97316"
        className="opacity-30"
      >
        <animate
          attributeName="opacity"
          values="0.1;0.4;0.1"
          dur="4s"
          begin={`${delay}s`}
          repeatCount="indefinite"
        />
        <animate
          attributeName="r"
          values={`${size};${size + 1};${size}`}
          dur="4s"
          begin={`${delay}s`}
          repeatCount="indefinite"
        />
      </circle>
      <circle
        cx={x}
        cy={y}
        r={size + 6}
        fill="none"
        stroke="#ea580c"
        strokeWidth="0.5"
        className="opacity-10"
      >
        <animate
          attributeName="opacity"
          values="0;0.2;0"
          dur="4s"
          begin={`${delay}s`}
          repeatCount="indefinite"
        />
      </circle>
    </g>
  );
};

const ConnectionLine: React.FC<{
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  delay?: number;
}> = ({ x1, y1, x2, y2, delay = 0 }) => {
  const pathLength = Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);
  
  return (
    <g>
      <line
        x1={x1}
        y1={y1}
        x2={x2}
        y2={y2}
        stroke="#1a1a1a"
        strokeWidth="0.8"
        className="opacity-15"
      />
      <line
        x1={x1}
        y1={y1}
        x2={x2}
        y2={y2}
        stroke="#c2410c"
        strokeWidth="1"
        className="opacity-0"
        strokeDasharray={pathLength}
        strokeDashoffset={pathLength}
      >
        <animate
          attributeName="stroke-dashoffset"
          values={`${pathLength};0;${pathLength}`}
          dur="8s"
          begin={`${delay}s`}
          repeatCount="indefinite"
        />
        <animate
          attributeName="opacity"
          values="0;0.3;0"
          dur="8s"
          begin={`${delay}s`}
          repeatCount="indefinite"
        />
      </line>
    </g>
  );
};

const DataPacket: React.FC<{
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  delay?: number;
}> = ({ x1, y1, x2, y2, delay = 0 }) => {
  return (
    <circle
      r="1.5"
      fill="#f97316"
      className="opacity-40"
    >
      <animateMotion
        dur="12s"
        begin={`${delay}s`}
        repeatCount="indefinite"
        path={`M ${x1} ${y1} L ${x2} ${y2}`}
      />
      <animate
        attributeName="opacity"
        values="0;0.5;0.5;0"
        dur="12s"
        begin={`${delay}s`}
        repeatCount="indefinite"
      />
    </circle>
  );
};

const CircuitPath: React.FC<{
  d: string;
  delay?: number;
}> = ({ d, delay = 0 }) => {
  return (
    <g>
      <path
        d={d}
        stroke="#0a0a0a"
        strokeWidth="1"
        fill="none"
        className="opacity-10"
      />
      <path
        d={d}
        stroke="#9a3412"
        strokeWidth="0.6"
        fill="none"
        className="opacity-0"
        strokeDasharray="6 3"
      >
        <animate
          attributeName="stroke-dashoffset"
          values="0;-9"
          dur="8s"
          begin={`${delay}s`}
          repeatCount="indefinite"
        />
        <animate
          attributeName="opacity"
          values="0;0.25;0"
          dur="8s"
          begin={`${delay}s`}
          repeatCount="indefinite"
        />
      </path>
    </g>
  );
};

const GridLines: React.FC = () => {
  const lines = [];
  const width = 1920;
  const height = 1080;
  const spacing = 60;

  // Vertical lines
  for (let x = 0; x <= width; x += spacing) {
    lines.push(
      <line
        key={`v-${x}`}
        x1={x}
        y1={0}
        x2={x}
        y2={height}
        stroke="#0a0a0a"
        strokeWidth="0.25"
        className="opacity-10"
      />
    );
  }

  // Horizontal lines
  for (let y = 0; y <= height; y += spacing) {
    lines.push(
      <line
        key={`h-${y}`}
        x1={0}
        y1={y}
        x2={width}
        y2={y}
        stroke="#0a0a0a"
        strokeWidth="0.25"
        className="opacity-10"
      />
    );
  }

  return <g>{lines}</g>;
};

const ITVideoBackground: React.FC = () => {
  const nodes = [
    { x: 200, y: 150, delay: 0 },
    { x: 500, y: 200, delay: 0.5 },
    { x: 800, y: 100, delay: 1 },
    { x: 1100, y: 250, delay: 1.5 },
    { x: 1400, y: 180, delay: 2 },
    { x: 300, y: 400, delay: 0.3 },
    { x: 700, y: 450, delay: 0.8 },
    { x: 1200, y: 500, delay: 1.3 },
    { x: 400, y: 700, delay: 0.6 },
    { x: 900, y: 750, delay: 1.1 },
    { x: 1300, y: 800, delay: 1.6 },
    { x: 150, y: 600, delay: 0.4 },
    { x: 600, y: 650, delay: 0.9 },
    { x: 1000, y: 350, delay: 1.4 },
  ];

  const connections = [
    { x1: 200, y1: 150, x2: 500, y2: 200, delay: 0 },
    { x1: 500, y1: 200, x2: 800, y2: 100, delay: 0.2 },
    { x1: 800, y1: 100, x2: 1100, y2: 250, delay: 0.4 },
    { x1: 1100, y1: 250, x2: 1400, y2: 180, delay: 0.6 },
    { x1: 300, y1: 400, x2: 700, y2: 450, delay: 0.8 },
    { x1: 700, y1: 450, x2: 1200, y2: 500, delay: 1 },
    { x1: 400, y1: 700, x2: 900, y2: 750, delay: 1.2 },
    { x1: 900, y1: 750, x2: 1300, y2: 800, delay: 1.4 },
    { x1: 200, y1: 150, x2: 300, y2: 400, delay: 0.1 },
    { x1: 500, y1: 200, x2: 700, y2: 450, delay: 0.3 },
    { x1: 800, y1: 100, x2: 1000, y2: 350, delay: 0.5 },
    { x1: 150, y1: 600, x2: 400, y2: 700, delay: 0.7 },
    { x1: 600, y1: 650, x2: 900, y2: 750, delay: 0.9 },
  ];

  const circuitPaths = [
    "M 50 50 L 150 50 L 150 150 L 250 150",
    "M 1600 100 L 1700 100 L 1700 200 L 1800 200",
    "M 100 900 L 200 900 L 200 800 L 300 800",
    "M 1500 950 L 1600 950 L 1600 850 L 1700 850",
    "M 50 500 L 100 500 L 100 450 L 150 450 L 150 400",
    "M 1650 600 L 1700 600 L 1700 650 L 1750 650 L 1750 700",
  ];

  return (
    <div className="fixed inset-0 -z-10 overflow-hidden">
      {/* Pure black base background */}
      <div className="absolute inset-0 bg-black" />
      
      {/* Subtle animated overlays with orange hints */}
      <div className="absolute inset-0 opacity-15">
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-radial from-orange-950/20 via-transparent to-transparent animate-pulse" 
             style={{ animationDuration: '15s' }} />
        <div className="absolute bottom-0 right-0 w-full h-full bg-gradient-radial from-gray-900/15 via-transparent to-transparent animate-pulse" 
             style={{ animationDuration: '20s', animationDelay: '5s' }} />
      </div>

      {/* SVG Network Animation */}
      <svg
        className="absolute inset-0 w-full h-full"
        viewBox="0 0 1920 1080"
        preserveAspectRatio="xMidYMid slice"
      >
        <defs>
          <filter id="orangeGlow">
            <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
            <feMerge> 
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
          
          <linearGradient id="orangeDataGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#ea580c" stopOpacity="0.3" />
            <stop offset="50%" stopColor="#f97316" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#c2410c" stopOpacity="0.2" />
          </linearGradient>
        </defs>

        {/* Subtle grid background */}
        <GridLines />

        {/* Circuit paths */}
        {circuitPaths.map((path, index) => (
          <CircuitPath
            key={`circuit-${index}`}
            d={path}
            delay={index * 0.8}
          />
        ))}

        {/* Connection lines */}
        {connections.map((conn, index) => (
          <ConnectionLine
            key={`conn-${index}`}
            {...conn}
          />
        ))}

        {/* Network nodes */}
        {nodes.map((node, index) => (
          <NetworkNode
            key={`node-${index}`}
            {...node}
            size={3 + (index % 2)}
          />
        ))}

        {/* Data packets */}
        {connections.slice(0, 6).map((conn, index) => (
          <DataPacket
            key={`packet-${index}`}
            {...conn}
            delay={index * 1.2}
          />
        ))}

        {/* Flowing energy streams with orange tones */}
        <g filter="url(#orangeGlow)">
          {[0, 1, 2].map((i) => (
            <circle
              key={`energy-${i}`}
              r="1.5"
              fill="url(#orangeDataGradient)"
            >
              <animateMotion
                dur="25s"
                begin={`${i * 5}s`}
                repeatCount="indefinite"
                path="M 0 540 Q 480 200 960 540 Q 1440 880 1920 540"
              />
              <animate
                attributeName="r"
                values="1;3;1"
                dur="4s"
                begin={`${i * 5}s`}
                repeatCount="indefinite"
              />
            </circle>
          ))}
        </g>
      </svg>

      {/* Minimal noise texture overlay */}
      <div className="absolute inset-0 opacity-[0.01] mix-blend-overlay pointer-events-none noise" />
    </div>
  );
};

export default ITVideoBackground;
